package com.example.user.eazymca;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;

public class Evaluation extends AppCompatActivity {
    RadioButton radioButton;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluation);


         button= findViewById(R.id.eval);
        radioButton= findViewById(R.id.radio);

    }
}
